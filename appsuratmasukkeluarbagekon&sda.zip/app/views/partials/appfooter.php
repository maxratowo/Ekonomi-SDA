<footer class="footer border-top" style="background-color: rgba(0, 0, 0, 0.45);">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4">
				<div class="copyright">
					Website By Max Juniar Ratowo | &copy; <?php echo SITE_NAME ?> - <?php echo date('Y') ?>
				</div>
			</div>
			<div class="col">
				<div class="footer-links text-right">
					<a href="<?php print_link('info/about'); ?>">About us</a> |
					<a href="<?php print_link('info/help'); ?>">Help and FAQ</a> |
					<a href="<?php print_link('info/contact'); ?>">Contact us</a> |
					<a href="<?php print_link('info/privacy_policy'); ?>">Privacy Policy</a> |
					<a href="<?php print_link('info/terms_and_conditions'); ?>">Terms and Conditions</a>
				</div>
			</div>
		</div>
	</div>
</footer>


<style>
	.footer {
		color: white;
		font-weight: bold;
	}
</style>
