<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="fa fa-home fa-3x"></i>'
		),
		
		array(
			'path' => 'surat_keluar', 
			'label' => 'Surat Keluar', 
			'icon' => '<i class="fa fa-envelope fa-3x"></i>'
		),
		
		array(
			'path' => 'surat_masuk', 
			'label' => 'Surat Masuk', 
			'icon' => '<i class="fa fa-envelope fa-3x"></i>'
		),
		
		array(
			'path' => 'pengguna', 
			'label' => 'Pengguna', 
			'icon' => '<i class="fa fa-user fa-3x"></i>'
		)
	);
		
	
	
}